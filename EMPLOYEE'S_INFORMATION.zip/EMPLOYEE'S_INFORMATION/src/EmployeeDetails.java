import java.util.Scanner;

class InvalidEmployeeException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidEmployeeException(String message) {
        super(message);
    }
}

public class EmployeeDetails {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Enter Employee Name: ");
            String name = scanner.nextLine();
            validateName(name);

            System.out.print("Enter Employee ID (2001-5001): ");
            int empId = scanner.nextInt();
            validateEmployeeId(empId);

            System.out.print("Enter Department ID (1-5): ");
            int deptId = scanner.nextInt();
            validateDepartmentId(deptId);

            System.out.println("\n--- Employee Details ---");
            System.out.println("Name: " + name);
            System.out.println("Employee ID: " + empId);
            System.out.println("Department ID: " + deptId);

        } catch (InvalidEmployeeException e) {
            System.out.println("Validation Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Input Error: Please enter valid data.");
        } finally {
            scanner.close();
            System.out.println("Scanner closed.");
        }
    }

    private static void validateName(String name) throws InvalidEmployeeException {
        if (name.isEmpty() || !Character.isUpperCase(name.charAt(0))) {
            throw new InvalidEmployeeException("First letter of employee name must be a capital letter.");
        }
    }

    private static void validateEmployeeId(int empId) throws InvalidEmployeeException {
        if (empId < 2001 || empId > 5001) {
            throw new InvalidEmployeeException("Employee ID must be between 2001 and 5001.");
        }
    }

    private static void validateDepartmentId(int deptId) throws InvalidEmployeeException {
        if (deptId < 1 || deptId > 5) {
            throw new InvalidEmployeeException("Department ID must be between 1 and 5.");
        }
    }
}
